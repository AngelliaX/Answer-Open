<?php
namespace tung;

use pocketmine\plugin\Plugin;
use pocketmine\scheduler\PluginTask;


class PopupTask extends PluginTask {
    public $cauhoi;    
 
   public function __construct(Plugin $owner,$cauhoi){
	 $this->cauhoi = $cauhoi;
	 $this->owner = $owner;
//	 $this->getOwner()->getServer()->broadcastPopup($cauhoi);
   }
   
   
   public function onRun($Tick){
   $this->getOwner()->getServer()->broadcastPopup($this->cauhoi);
   }
}