<?php
namespace tung; 
 
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\permission\DefaultPermissions;

class Main extends PluginBase{
         public $repeattime = 0.000000001;	
//cac bien tren se dc chuyen qua dung config sau khi plugin hoat dong	
	
    public function onEnable(){
		 $this->saveDefaultConfig();
         $this->reloadConfig();
		 $this->getLogger()->info("ยงlยงdPlugin tra loi cau hoi ");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args):bool{
            $a = $this->getConfig()->get("CauHoi"); 
			$b = $this->getConfig()->get("CauTraLoi"); 
			foreach($a as $so => $cauhoi){
              foreach($b as $soo => $traloi){  
                 if(strtolower($command->getName()) === "ask"){
				  if(isset($args[0])){	 
                    if($args[0] == $so){
					   $this->getServer()->getScheduler()->scheduleRepeatingTask(new PopupTask($this,$cauhoi),$this->repeattime);
					 }
				  }
				 }
                 if($so == $soo){				 
			      if(strtolower($command->getName()) === "trl") {
				   if(isset($args[0])){
			      	 if($args[0]== $traloi){
				     $sender->sendMessage("Ban da tra loi dung");
					 $this->getServer()->dispatchCommand (new ConsoleCommandSender(),"ask ".rand(0,count($a)-1));                     
					 break;			 
				     }
				
				   }
			      }
				 }
			  }
			}
			return true;
	}
}